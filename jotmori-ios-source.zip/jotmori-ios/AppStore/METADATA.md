# بيانات تقديم Jotmori / جوتموري — 1.0.0 (2)

الهوية الحالية Jotmori: Private Notes بالإنجليزية وجوتموري — ملاحظاتك الخاصة بالعربية. الإنجليزية هي اللغة الأساسية المستهدفة مع دعم العربية واختيار اللغة داخل التطبيق. تفاصيل الفحص الأولي وحدوده في NAME_REVIEW.md، والنص الإنجليزي في en-US.json. لا يوجد ضمان خلو الاسم من الحقوق عالميًا.

السجل القائم: Apple ID 6825094170؛ Bundle ID com.alawyadnan.waraqa؛ Team ID PWC93S9KK8. المسار المعتمد نشر عام في App Store ثم ريديت بعد موافقة Apple. البناء السابق 1.0.0 (1) مرفوع، والبناء الجديد (2) مؤرشف؛ لا يُعلن رفعه أو تقديمه قبل تأكيد Apple.

## النص الترويجي

اكتب أفكارك في مساحة عربية هادئة. حفظ محلي، بحث سريع، تنظيم بسيط، ونسخ احتياطية تحت سيطرتك — دون حساب أو إعلانات.

## الوصف

بعض الأفكار تحتاج فقط إلى مساحة هادئة.

جوتموري تطبيق ملاحظات لـ iPhone بالعربية والإنجليزية، يساعدك على التقاط الفكرة وترتيب يومك والاحتفاظ بما تريد تذكّره. افتح التطبيق وابدأ الكتابة، دون حساب أو اتصال بالإنترنت.

مساحة بسيطة:
• اكتب ملاحظاتك مع حفظ تلقائي محلي.
• نظّمها بمجلدات ووسوم، وثبّت ما تحتاجه دائمًا.
• ابحث في العناوين والمحتوى والوسوم، مع مراعاة اختلافات الألف والتشكيل.
• استخدم معاينة Markdown وقوائم المهام التفاعلية.
• أرشف الملاحظات أو انقلها إلى المحذوفات واستعدها عند الحاجة.
• صدّر ملاحظة نصية أو نسخة كاملة، واستورد ملفات النص وMarkdown ونسخ جوتموري عبر تطبيق الملفات.

أفكارك، لك وحدك:
• لا حسابات ولا إعلانات ولا أدوات تتبّع في التطبيق.
• تبقى الملاحظات على الجهاز، ولا تُرسل إلى خادم المطوّر.
• أضف قفلًا اختياريًا بكلمة مرور لتشفير المساحة ونسخها الاحتياطية الكاملة.
• كلمة المرور تبقى على جهازك، ولا يمكن استعادتها عند فقدها.

جوتموري مجاني ومفتوح المصدر برخصة MIT. لا توجد اشتراكات أو مشتريات داخل التطبيق في هذا الإصدار. المزامنة بين الأجهزة والقوائم المشتركة غير متاحة حاليًا.

احتفظ بنسخ احتياطية خارج التطبيق؛ حذف التطبيق قد يحذف ملاحظاته المحلية. لم يخضع هذا الإصدار لتدقيق أمني مستقل.

## الكلمات المفتاحية

ملاحظات,كتابة,دفتر,يوميات,أفكار,قوائم,مهام,عربي,خصوصية,تدوين,تنظيم

## ملاحظات المراجعة بالإنجليزية

Jotmori 1.0.0 (2) is a native SwiftUI English and Arabic note-taking app for iPhone. No account, sign-in, server connection, in-app purchase or subscription is required.

Open a sample note or tap the compose button to create one. The filter menu switches between all notes, pinned notes, archive, trash, folders and tags. The editor offers writing and preview modes, native file export, pinning, folder assignment and recoverable deletion. Task checkboxes in preview update the note.

Settings offers native Files import/export, folder management and optional password encryption. To test encryption, use a new test password of at least 12 characters and keep it for unlocking. Encryption covers titles, content, folders and tags, using Apple's CryptoKit AES-256-GCM and CommonCrypto PBKDF2-SHA-256 with 600,000 iterations. The password/key is not uploaded or persisted. The app locks when backgrounded and after five minutes of inactivity. Backup export remains encrypted when the space is encrypted; single-note Markdown export requires confirmation because it is plaintext.

The current release is fully local and free. Future sync and shared-list services are not implemented or advertised as available. All sample content is fictional and removable. There are no third-party SDKs, advertising, analytics or remote code downloads.

## التشفير

تشفير الإصدار الحالي يستخدم CryptoKit وCommonCrypto المقدمين ضمن نظام Apple، دون تنفيذ خارجي لخوارزميات التشفير. تنص وثيقة Apple الخاصة بالتشفير المحدود لما يوفره النظام على عدم الحاجة إلى مستندات تشفير داخل App Store Connect؛ ضُبط ITSAppUsesNonExemptEncryption على false لهذا التنفيذ. هذا لا يعني أن التطبيق لا يستخدم التشفير. تُراجع أسئلة Apple الفعلية عند إكمال التقديم.

المصدر: https://developer.apple.com/help/app-store-connect/reference/app-information/export-compliance-documentation-for-encryption

## مراجع Apple

- https://developer.apple.com/help/app-store-connect/manage-submissions-to-app-review/submit-an-app/
- https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-privacy/
- https://developer.apple.com/app-store/review/guidelines/#minimum-functionality