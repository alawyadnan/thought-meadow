# Jotmori — local notes for iPhone

تطبيق ملاحظات أصلي بالإنجليزية والعربية بـ SwiftUI، يستهدف iPhone وiOS 17 أو أحدث. النسخة المحلية مجانية ومفتوحة المصدر برخصة MIT؛ المزامنة والقوائم المشتركة والاشتراك المقترح لاحقًا ليست جزءًا من الإصدار 1.0.0.

## فتح المشروع

افتح `Waraqa.xcodeproj` في Xcode، واختر scheme باسم Waraqa.

للبناء دون توقيع أثناء التحقق:

```sh
xcodebuild -project Waraqa.xcodeproj -scheme Waraqa -configuration Debug -destination 'generic/platform=iOS' -derivedDataPath /tmp/WaraqaBuild CODE_SIGNING_ALLOWED=NO build
```

البناء دون توقيع ليس ملف IPA صالحًا للمتجر. قبل Archive يجب اختيار فريق المطوّر الفعلي في Signing & Capabilities والتحقق من Bundle ID؛ معرّف الحزمة القائم هو com.alawyadnan.waraqa؛ يحتفظ بالاسم التقني السابق لتوافق البيانات. الاسم الظاهر الجديد Jotmori، والبناء الحالي 1.0.0 (2).

## البيانات والخصوصية

الملاحظات بصيغة متوافقة مع نسخة الويب في Application Support. الكتابة ذرية، مع نسخة محلية من آخر حفظ. الملفات تستخدم حماية iOS الكاملة أثناء قفل الجهاز؛ القفل الاختياري يشفّر محتوى المساحة نفسه باستخدام AES-256-GCM وPBKDF2-SHA-256 من كلمة مرور المستخدم. لا تُخزّن كلمة المرور أو المفتاح بعد القفل.

تُزال نسخة الاستعادة المحلية الواضحة عند تفعيل التشفير. النسخ التي صدّرها المستخدم خارج التطبيق لا يشملها ذلك، ولا يوجد ضمان للمحو الجنائي للذاكرة أو وسيط التخزين. عند فشل فتح البيانات، لا يستبدلها التطبيق بأمثلة جديدة؛ يتيح تنزيل السجل للفحص أو استعادة آخر حفظ سابق.

مجلد البيانات مستبعد من النسخ السحابي التلقائي. حذف التطبيق قد يحذف الملاحظات، لذلك يلزم تصدير نسخ احتياطية. عند التصدير إلى خدمة سحابية عبر «الملفات»، يختار المستخدم الخدمة بنفسه؛ التطبيق لا ينقل المحتوى إلى خادم خاص به.

هذه نسخة أولى لم تخضع لتدقيق أمني مستقل. تتطلب اختبارات فعلية على iPhone ومراجعة الوصولية، ولا يُعلن نجاح تقديمها إلى Apple قبل التحقق من App Store Connect.

## الاختبارات

توجد اختبارات native في `Tests/NativeChecks.swift` تشمل الحفظ والتشفير والقفل والتحقق والاستيراد، ويمكن تجميعها على macOS مع Models.swift وVaultCrypto.swift وNotebookStore.swift. تُختبر أيضًا قراءة النسخ المشفرة من الويب وبالعكس. تطبيق واجهة SwiftUI الكامل يبنى من مشروع Xcode.

## التقديم

مسودة بيانات المتجر في `AppStore/METADATA.md`. صفحات الدعم والخصوصية في `SupportSite/`. لا يوجد دفع أو كود يتصل بشبكة في التطبيق. مصدر التطبيق والنسخة السابقة مرخّصان برخصة MIT.

## Language and naming

English is the development language. Arabic devices use the Arabic interface; other devices use English. Settings can override this with English, العربية, or the device language. Changing language never translates existing user notes. The internal project and data format retain the original Waraqa name. See AppStore/NAME_REVIEW.md for the preliminary name search and its limits; no worldwide clearance or trademark registration is claimed.
