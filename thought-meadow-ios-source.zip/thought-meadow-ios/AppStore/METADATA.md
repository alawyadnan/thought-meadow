# Thought Meadow — 1.0.0 (4)

الاسم الإنجليزي: Thought Meadow - Private Notes. العربي: مرج الأفكار - ملاحظات خاصة. بيانات الوصف والكلمات والنص الترويجي في en-US.json وar.json. لا توجد مشتريات أو اشتراكات في الإصدار الأول.

Apple ID: 6825094170. Bundle ID: com.alawyadnan.waraqa. Team ID: PWC93S9KK8.

اللغتان داخل التطبيق: الإنجليزية افتراضيًا للأجهزة غير العربية، والعربية للأجهزة العربية، مع اختيار اللغة في الإعدادات. سجل المتجر يحتفظ بالعربية لغة أساسية حاليًا، مع ترجمة إنجليزية مستقلة.

السعر: مجاني. الإتاحة العامة بعد موافقة Apple. يُنشر في ريديت بعد الموافقة فقط. راجع VALIDATION.md للحالة الفعلية؛ رفع البناء لا يعني التقديم أو الموافقة.

التشفير يستخدم أطر Apple النظامية CryptoKit وCommonCrypto؛ ITSAppUsesNonExemptEncryption=false لا يعني انعدام التشفير، وإنما وصف استخدام التشفير المعفى ضمن هذا التنفيذ. المرجع: https://developer.apple.com/help/app-store-connect/reference/app-information/export-compliance-documentation-for-encryption

الدعم: allaw.68@gmail.com. بيانات اتصال المراجع الخاصة تُدخل إلى Apple فقط وتُستبعد من المصدر العام.
