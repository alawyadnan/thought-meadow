# فحص الاسم — Thought Meadow / مرج الأفكار

آخر تحديث: ٢١ أكتوبر ٢٠٢٦.

اختار المالك صراحةً **Thought Meadow - Private Notes**، وبالعربية **مرج الأفكار - ملاحظات خاصة**. المعنى المقصود: مساحة تنمو فيها الأفكار. الاسم الإنجليزي 30 محرفًا، والعربي 26، دون تغيير المعرف التقني com.alawyadnan.waraqa.

## نتائج الفحص الأولي

- لم يظهر تطبيق ملاحظات مطابق في البحث العام عن Thought Meadow وThoughtMeadow، أو عبارة «مرج الأفكار» ضمن النتائج المتاحة. ظهر عنوان منتج ملابس يجمع Thought وMeadow؛ لا يُعد ذلك إثباتًا لتسجيل علامة للبرمجيات ولا حكمًا بانتفاء التعارض.
- في [USPTO Trademark Search](https://tmsearch.uspto.gov/search/) استُخدم General search مع `CM:"thought meadow" OR CM:thoughtmeadow`، ثم `CM:(thought* AND meadow*) OR CM:thoughtmeadow*`. أعاد البحثان No results found. دليل الصورة خارج المصدر: thought-meadow-uspto-search.png.
- في [EUIPO eSearch](https://euipo.europa.eu/eSearch/) أعاد البحث Thought Meadow صفر نتائج. دليل الصورة: thought-meadow-euipo-search.png.
- حُفظ الاسم العربي والإنجليزي في App Store Connect مع تأكيد Saved. توفر الاسم في المتجر ليس تصريحًا بحقوق العلامة.
- لم يكتمل فحص WIPO بسبب حجب المتصفح السابق، ولا بحث شامل في السجلات الوطنية، بما فيها السعودية، أو جميع الأسماء المتشابهة صوتًا وترجمةً. لم تُشترَ خدمة بحث أو نطاق ولم يُقدّم تسجيل علامة.

هذه نتائج محدودة وليست ضمان خلو عالمي أو رأيًا قانونيًا نهائيًا. [USPTO](https://www.uspto.gov/trademarks/search/likelihood-confusion) يربط احتمال الالتباس بتشابه العلامات وارتباط السلع أو الخدمات. وتوصي [WIPO](https://www.wipo.int/en/web/global-brand-database) بالرجوع أيضًا إلى السجلات الوطنية والإقليمية.

## قرارات الهوية السابقة

استُبعد Paper لوجود [Paper: Writing App, Notes](https://apps.apple.com/us/app/paper-writing-app-notes/id1476984841) في المجال نفسه، وبقي Waraqa اسمًا تقنيًا فقط لوجود [Waraqa - Simple Daily Tasks](https://apps.apple.com/us/app/waraqa-simple-daily-tasks/id6820619804). لم تُعتمد ملكية حصرية لهذه الكلمات أو وقوع تعدٍّ كحقيقة قانونية.

اختير Jotmori ثم Alawynote مبدئيًا. أظهر App Store Connect أخطاء أسماء عند محاولة تغيير اللغة الأساسية؛ لا يثبت ذلك وجود علامة مسجلة. حُفظ Alawynote لاحقًا في نموذج جديد، ثم رفض المالك الاسم لعدم وضوح معناه واختار Thought Meadow. لم يُقدّم أي بناء سابق لمراجعة App Store.

المصدر الأصلي برخصة MIT، ولا يمنح حقوق علامات أطراف أخرى. تراخيص أطر Apple وأصول النظام مستقلة، كما هو مبين في NOTICE.md.
